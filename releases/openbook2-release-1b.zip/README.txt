OpenBook2

Release 1b, 09 May 2007

OpenBook2 incorporates the following libraries and applications:
 * OpenGL,
 * GLUT,
 * ZThreads,
 * Frotz.

They are all protected by the GPL.

===
This archive contains:
 * Openbook2.exe
 * textures/paper.bmp
 * textures/cover.bmp
 * stories/planetfall.z5
 * README.txt (this file)

NB. Planetfall is still property of Infocom.

===
To run:

- Extract all files into a fresh folder somewhere.
- Run Openbook2.exe

===
Please report any problems to: lewis@cantab.net
